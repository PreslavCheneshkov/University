<?php 
print("<html>");
print("<head><title>Моята първа прграма на PHP</title></head>");
print("<body>");
print("<font color=red>Здравей свят!</font>");
print("</body></html>");
 ?>