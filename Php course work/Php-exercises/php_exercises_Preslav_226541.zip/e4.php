<?php
    print("<center>");
    $ru = "Русенски университет";
    $city = "гр.Русе";
    print("<b>\"$ru\"</b>"."<i>$city</i>"."<br>");
    $address = "ул. \"Студентска\" N8";
    print("$address");
    print("</center>");
?>