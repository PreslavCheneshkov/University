<?php
    $varA = 5;
    $varB = 6;
    if ($varA == 5 && $varB == 6) {
        print("Браво! Позна!");    
    } else {
        print("Грешиш приятел!");
    }
?>